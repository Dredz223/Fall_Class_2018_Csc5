/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on October 18, 2018, 12:14 PM
 * Purpose:  Sum with Numbers
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int val,//Our Positive value
        n,
        sum;
    //Enter the Value
    cout<<"Please enter a positive integer value.\n"<<
            "------------------------------------"<<endl;
    cin>>val;
    
    //Calculation
    for(int n = 0; n <= val ; n++){
        if(n<1){
            cout<<"Value must be POSITIVE!!!"<<endl;
        }
        else if(n>=1 && n<=val){
            sum=sum+n;
            cout<<"The number of value is "<<n<<"\t\t"<<"and the sum is "<<sum<<endl;
        }
    }
    //Process/Calculations Here
    
    //Output Located Here

    //Exit
    return 0;
}

