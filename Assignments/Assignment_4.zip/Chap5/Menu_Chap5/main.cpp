/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on October 4th, 2018, 10:25 AM
 * Purpose:  Menu Template
 */


//System Libraries Here
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime> 
#include <cmath> 
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions
const unsigned char CNVPDOL=100;//Number of pennies in a dollar
//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    char choice;//Option 0 to 9 input as a character not a numeric value
    
    //Loop until you want to exit
    do{
        //Input or initialize values Here
        cout<<"This program illustrates a Menu"<<endl;
        cout<<"Choose the problem you wish to solve"<<endl;
        cout<<"0 -> Gaddis_9thEd_Chap5_Prob1_Sum_With_Numbers"<<endl;
        cout<<"1 -> Gaddis_9thEd_Chap5_Prob3_Ocean_Levels"<<endl;
        cout<<"2 -> Gaddis_9thEd_Chap5_Prob4_Calories_Burned"<<endl;
        cout<<"3 -> Gaddis_9thEd_Chap5_Prob5_Membership_Fees_Increased"<<endl;
        cout<<"4 -> Gaddis_9thEd_Chap5_Prob6_Distance_Traveled"<<endl;
        cout<<"5 -> Gaddis_9thEd_Chap5_Prob7_Double_Pay_Per_Day"<<endl;
        cout<<"6 -> Gaddis_9thEd_Chap5_Prob10_Average_RainFall"<<endl;
        cout<<"7 -> Gaddis_9thEd_Chap5_Prob20_Guessing_Game"<<endl;
        cout<<"8 -> Gaddis_9thEd_Chap5_Prob21_Guessing_Game_Enhanced"<<endl;
        cin>>choice;

        //Process/Calculations Here
        switch(choice){
            case '0':{
                cout<<"Put solution to Prob 1 here"<<endl;
                //coding goes here
                //Declare all Variables Here
                int val,//Our Positive value
                      n,
                    sum;
                //Enter the Value
                    cout<<"Please enter a positive integer value.\n"<<
                            "------------------------------------"<<endl;
                    cin>>val;
    
                //Calculation
                for(int n = 0; n <= val ; n++){
                if(n<1){
                cout<<"Value must be POSITIVE!!!"<<endl;
                }
                else if(n>=1 && n<=val){
                    sum=sum+n;
                    cout<<"The number of value is "<<n<<"and the sum is "<<sum<<endl;
                }
            }
            }        
                break;
            case '1':{
                cout<<"Put solution to Prob 3 here"<<endl;
                //coding goes here
                //Declare all Variables Here
    float ocenlvl = 1.5,//1.5 Millimeters per year 
          yrs,          //Years
          totlvl;       //Total Ocean Level
    
    //Process/Calculations Here
    for(int yrs = 1; yrs <= 25; yrs++){
         totlvl = ocenlvl * yrs;
         cout<<"The Ocean level is currently rising "<<totlvl
                 <<" millimeters in "<<yrs<<" years."<<endl;
    }
            }
               break;
            case '2':{
                cout<<"Put solution to Prob 4 here"<<endl;
                //coding goes here
                //Declare all Variables Here
    float calbrn=3.6,//3.6 Calories Burned per minute 
          mins,      //Minutes on the treadmill
          totbrn;    //Total Calories Burned
    
    //Process/Calculations Here
    for(int mins = 5; mins <= 30; mins+=5){
        totbrn = calbrn * mins;
        cout<<"Total Calories burned in "<<mins<<" mins = "<<totbrn<<endl;
    }
            }
                break;
            case '3':{
                cout<<"Put solution to Prob 5 here"<<endl;
                //coding goes here
                float memship = 2500,//$2,500 per year membership 
          percnt  = 0.04,// 4% of the initial cost 
          yers,          //Years
          totcost;       //Total cost
    
    //Process/Calculations Here
    for(int yers = 1; yers <= 6; yers++){
         totcost = memship + (memship * (percnt * yers));
         cout<<"The new Membership cost is $"<<totcost
                 <<" for year "<<yers<<"."<<endl;
    }
            }
                break;
            case '4':{
                cout<<"Put solution to Prob 6 here"<<endl;
                //coding goes here
            //Declare Variables
    int sped,//Speed of vehicle in MPH
        hrs, //Time in HOURS
        dist;// Distance = SPEED * TIME 
    
    //Initial Variables
    cout<<"What is your speed in MPH?"<<endl;
    cin>>sped;
    cout<<"How long, in hours, did your travel take?"<<endl;
    cin>>hrs;
    
    //Validation
    if(sped<=0){
        cout<<"Speed cannot be negative!"<<endl;
        return(0);
    }
    if(hrs<1){
        cout<<"Time cannot be less than one!"<<endl;
        return(0);
    }

    //Map/Process Inputs to Outputs
    for(int t =1 ; t <= hrs; t++){
        dist = sped * t;
        cout<<"The total distance traveled is "<<dist<<" miles, in "<<t<<
                " hours."<<endl;
    }
            }
                break;
            case '5':{
                cout<<"Put solution to Prob 7 here"<<endl;
                //coding goes here
                //Declare all Variables Here
    unsigned int totPay; //Total Pay
    unsigned char nDays; //Number of Days
    
    //Input or initialize values Here
    nDays=30; //30 Days in this month
    totPay=0; //Initialize total pay to a dollar
    cout<<"This is a Pay Day problem"<<endl;
    cout<<"Your pay is doubled each day"<<endl;
    cout<<"starting with a penny."<<endl;
    
    //Process/Calculations Here
    cout<<fixed<<setprecision(2)<<showpoint;
    for(int day=1,pennies=1;day<=nDays;day++,pennies*=2){
        totPay+=pennies;
        cout<<"Day "<<setw(2)<<day<<" Pay = $"
                <<setw(8)<<pennies/CNVPDOL<<".";
        if(pennies%CNVPDOL<10) 
              cout<<"0"<<pennies%CNVPDOL<<endl;
        else  cout<<pennies%CNVPDOL<<endl;
        
    }
    
    //The Number randomly set
    cout<<"Total Pay  = $"<<totPay/CNVPDOL<<".";
    if(totPay%CNVPDOL<10) 
              cout<<"0"<<totPay%CNVPDOL<<endl;
    else cout<<totPay%CNVPDOL<<endl;
            }
                break;
            case '6':{
                cout<<"Put solution to Prob 10 here"<<endl;
                //coding goes here
                //Declare Variables
    float avgRnfa,//Average Rain Fall per month
            years,//Years of the total calculation
           inches,//Inches of rain asked for each month
           months,//12 months in 1 year
          totinch;//Total inches of rain for all months
    
    //Initial Variables
    cout<<"What is the number of years we are recording?"<<endl;
    cin>>years;
    
    //Validation
    if(years<1){
        cout<<"Years cannot be less than 1!!"<<endl;
        return(0);
    }
    
    //Map/Process Inputs to Outputs
    for(int i = 1; i<= years; i++){
        cout<<"Enter the inches of rain for the next 12 months."<<endl;
        for(int j = 1; j<=12; j++){
        cin>>inches;
            if(inches < 0){
                cout<<"Inches cannot be negative, must be 0 or higher!"<<endl;
                return(0);
            }
        totinch = inches + totinch;
        }
    }
    months = years * 12;
    avgRnfa = totinch/(months);
    //Display output
    cout<<"# of Months"<<"  "<<"Total Rainfall"<<"  "<<"Average Rainfall"<<endl;
    cout<<"-------------------------------------------------------"<<endl;
    cout<<months<<"\t\t"<<totinch<<"\t\t"<<avgRnfa<<endl;
            }
                break;
            case '7':{
                cout<<"Put solution to Prob 20 here"<<endl;
                //coding goes here
                //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare all Variables Here
    const unsigned short MXRAND=1000; //Max Random Number
    unsigned short number;            //Number randomly chosen to guess  
    unsigned short guess;             //Our Guess
    unsigned char nmTries;            //Number of tries to guess
    
    //Input or initialize values Here
    nmTries=log(MXRAND)/log(2)+1;
    number=rand()%(MXRAND+1);       //[0,MXRAND]
    cout<<"This is a guessing game"<<endl;
    cout<<"Guess the number from 0 to "<<MXRAND<<endl;
    cout<<"You have "<<static_cast<int>(nmTries)<<" guesses to find the number.\n"<<endl;
    
    //Process/Calculations Here
    for(int nGuess=1;nGuess<=nmTries&&guess!=number;nGuess++){
        cout<<"Input Guess "<<nGuess<<" = ";
        cin>>guess;
        if(number>guess)cout<<"Guess is too low\n\n";
        if(number<guess)cout<<"Guess is too high\n\n";
    }
    
    //The Number randomly set
    cout<<"The number randomly chosen = "<<number<<endl;
            }
                break;
            case '8':{
                cout<<"Put solution to Prob 21 here"<<endl;
                //coding goes here
                //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare all Variables Here
    const unsigned short MXRAND=10; //Max Random Number
    unsigned short number;            //Number randomly chosen to guess  
    unsigned short guess;             //Our Guess
    unsigned char nmTries;            //Number of tries to guess
    
    //Input or initialize values Here
    nmTries=log(MXRAND)/log(2)+1;
    number=rand()%(MXRAND+1);       //[0,MXRAND]
    cout<<"This is a guessing game"<<endl;
    cout<<"Guess the number from 0 to "<<MXRAND<<endl;
    cout<<"You have "<<static_cast<int>(nmTries)<<" guesses to find the number.\n"<<endl;
    
    //Process/Calculations Here
    for(int nGuess=1;nGuess<=nmTries&&guess!=number;nGuess++){
        cout<<"Input Guess "<<nGuess<<" = ";
        cin>>guess;
        if(number>guess)cout<<"Guess is too low\n\n";
        if(number<guess)cout<<"Guess is too high\n\n";
        if(nGuess==nmTries)
        cout<<"Congrats! You guessed correctly! It only took "<<nGuess<<" tries!"<<endl;
    }
    
    //The Number randomly set
    cout<<"The number randomly chosen = "<<number<<endl;
            }
                break;
            default:
                cout<<"Exiting the program?"<<endl;
            }
    }while(choice>='0'&&choice>='2');
    //Exit Stage Right
    return 0;
}

