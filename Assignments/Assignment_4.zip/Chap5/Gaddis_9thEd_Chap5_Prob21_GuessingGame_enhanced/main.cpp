/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on October 18, 2018, 11:17 PM
 * Purpose:  Guessing Game Enhanced 
 */

//System Libraries Here
#include <iostream> //I/o Library
#include <cstdlib>  //Random Number
#include <ctime>    //Time
#include <cmath>    //Math Library
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare all Variables Here
    const unsigned short MXRAND=10; //Max Random Number
    unsigned short number;            //Number randomly chosen to guess  
    unsigned short guess;             //Our Guess
    unsigned char nmTries;            //Number of tries to guess
    
    //Input or initialize values Here
    nmTries=log(MXRAND)/log(2)+1;
    number=rand()%(MXRAND+1);       //[0,MXRAND]
    cout<<"This is a guessing game"<<endl;
    cout<<"Guess the number from 0 to "<<MXRAND<<endl;
    cout<<"You have "<<static_cast<int>(nmTries)<<" guesses to find the number.\n"<<endl;
    
    //Process/Calculations Here
    for(int nGuess=1;nGuess<=nmTries&&guess!=number;nGuess++){
        cout<<"Input Guess "<<nGuess<<" = ";
        cin>>guess;
        if(number>guess)cout<<"Guess is too low\n\n";
        if(number<guess)cout<<"Guess is too high\n\n";
        if(nGuess==nmTries)
        cout<<"Congrats! You guessed correctly! It only took "<<nGuess<<" tries!"<<endl;
    }
    
    //The Number randomly set
    cout<<"The number randomly chosen = "<<number<<endl;
    //Output Located Here
    
    //Exit
    return 0;
}

