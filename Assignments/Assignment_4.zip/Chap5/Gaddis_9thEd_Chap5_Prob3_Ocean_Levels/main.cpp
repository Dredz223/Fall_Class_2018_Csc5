/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on October 18, 2018, 9:06 PM
 * Purpose:  Ocean Levels
 */

//System Libraries Here
#include <iostream>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions 

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float ocenlvl = 1.5,//1.5 Millimeters per year 
          yrs,          //Years
          totlvl;       //Total Ocean Level
    
    //Process/Calculations Here
    for(int yrs = 1; yrs <= 25; yrs++){
         totlvl = ocenlvl * yrs;
         cout<<"The Ocean level is currently rising "<<totlvl
                 <<" millimeters in "<<yrs<<" years."<<endl;
    }
    
    //Output Located Here

    //Exit
    return 0;
}

