/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on October 18, 2018, 8:27 PM
 * Purpose:  Calories Burned
 */

//System Libraries Here
#include <iostream>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions 

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float calbrn=3.6,//3.6 Calories Burned per minute 
          mins,      //Minutes on the treadmill
          totbrn;    //Total Calories Burned
    
    //Process/Calculations Here
    for(int mins = 5; mins <= 30; mins+=5){
        totbrn = calbrn * mins;
        cout<<"Total Calories burned in "<<mins<<" mins = "<<totbrn<<endl;
    }
    
    //Output Located Here

    //Exit
    return 0;
}

