/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on October 18, 2018 10:18PM
 * Purpose:  Average Rainfall
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float avgRnfa,//Average Rain Fall per month
            years,//Years of the total calculation
           inches,//Inches of rain asked for each month
           months,//12 months in 1 year
          totinch;//Total inches of rain for all months
    
    //Initial Variables
    cout<<"What is the number of years we are recording?"<<endl;
    cin>>years;
    
    //Validation
    if(years<1){
        cout<<"Years cannot be less than 1!!"<<endl;
        return(0);
    }
    
    //Map/Process Inputs to Outputs
    for(int i = 1; i<= years; i++){
        cout<<"Enter the inches of rain for the next 12 months."<<endl;
        for(int j = 1; j<=12; j++){
        cin>>inches;
            if(inches < 0){
                cout<<"Inches cannot be negative, must be 0 or higher!"<<endl;
                return(0);
            }
        totinch = inches + totinch;
        }
    }
    months = years * 12;
    avgRnfa = totinch/(months);
    //Display output
    cout<<"# of Months"<<"  "<<"Total Rainfall"<<"  "<<"Average Rainfall"<<endl;
    cout<<"-------------------------------------------------------"<<endl;
    cout<<months<<"\t\t"<<totinch<<"\t\t"<<avgRnfa<<endl;
    
    //Exit program!
    return 0;
}