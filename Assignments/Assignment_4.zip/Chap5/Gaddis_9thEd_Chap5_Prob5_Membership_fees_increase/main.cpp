/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on October 18, 2018, 9:24 PM
 * Purpose:  Membership Fee Increase
 */

//System Libraries Here
#include <iostream>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions 

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float memship = 2500,//$2,500 per year membership 
          percnt  = 0.04,// 4% of the initial cost 
          yers,          //Years
          totcost;       //Total cost
    
    //Process/Calculations Here
    for(int yers = 1; yers <= 6; yers++){
         totcost = memship + (memship * (percnt * yers));
         cout<<"The new Membership cost is $"<<totcost
                 <<" for year "<<yers<<"."<<endl;
    }
    
    //Output Located Here

    //Exit
    return 0;
}

