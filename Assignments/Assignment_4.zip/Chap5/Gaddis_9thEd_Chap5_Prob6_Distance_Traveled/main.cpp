/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on October 18, 2018 9:50PM
 * Purpose:  Distance Traveled
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int sped,//Speed of vehicle in MPH
        hrs, //Time in HOURS
        dist;// Distance = SPEED * TIME 
    
    //Initial Variables
    cout<<"What is your speed in MPH?"<<endl;
    cin>>sped;
    cout<<"How long, in hours, did your travel take?"<<endl;
    cin>>hrs;
    
    //Validation
    if(sped<=0){
        cout<<"Speed cannot be negative!"<<endl;
        return(0);
    }
    if(hrs<1){
        cout<<"Time cannot be less than one!"<<endl;
        return(0);
    }

    //Map/Process Inputs to Outputs
    for(int t =1 ; t <= hrs; t++){
        dist = sped * t;
        cout<<"The total distance traveled is "<<dist<<" miles, in "<<t<<
                " hours."<<endl;
    }
        
    //Exit program!
    return 0;
}