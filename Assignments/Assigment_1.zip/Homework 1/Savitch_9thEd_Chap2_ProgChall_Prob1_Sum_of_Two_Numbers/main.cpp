/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 6, 2018, 10:01 AM
 * Purpose:  Sum of 2 numbers 
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    short num1, num2, sum;
    
    //Input or initialize values Here
        num1=50;//Value being 50 
        num2=100;// Value being 100
    
    //Process/Calculations Here
        sum=num1+num2;//The values being added to make the sum
        
    //Output Located Here
    cout<<sum<< "="<<num1<<" + "<<num2<<endl;

    //Exit
    return 0;
}

