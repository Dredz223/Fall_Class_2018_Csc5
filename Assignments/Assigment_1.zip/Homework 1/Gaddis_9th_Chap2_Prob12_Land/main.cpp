/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 6, 2018, 11:45 AM
 * Purpose:  Great Land Grab
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions
const unsigned short CNVACFT=43560;//Conversion from Acres to feet
//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float areaFt2,//Area in ft^2
          areaAc; //Area in acres
    //Input or initialize values Here
    cout<<"This program converts ft^2 to acres"<<endl;
    cout<<"Input ft^2"<<endl;
    cin>>areaFt2;
    
    //Process/Calculations Here
    areaAc=areaFt2/CNVACFT;
            
    //Output Located Here
    cout<<areaFt2<<"ft^2 = "<<areaAc<<" acres" <<endl;

    //Exit
    return 0;
}

