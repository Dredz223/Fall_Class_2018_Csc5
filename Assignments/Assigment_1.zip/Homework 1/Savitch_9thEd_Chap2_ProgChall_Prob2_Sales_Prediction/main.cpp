/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 10, 2018, 8:04 PM
 * Purpose:  Sales Tax
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float pRchse=95;//95 Dollar Purchase 
    float sTSlsTx=.04;//State Sales Tax Percentage 0.04% 
    float ctyslTx=.02;//County Sales Tax percentage 0.02%
    float totTx;//Total Tax of State Sales Tax and County Sales Tax
    float ttTxpRc;//Total Tax on the Purchase
    //Input or initialize values Here
    
    
    //Process/Calculations Here
    totTx=sTSlsTx+ctyslTx;
    ttTxpRc=totTx*pRchse;
    //Output Located Here
    cout<<"Total Sales Tax on Purchase ="<<ttTxpRc<<endl;

    //Exit
    return 0;
}

