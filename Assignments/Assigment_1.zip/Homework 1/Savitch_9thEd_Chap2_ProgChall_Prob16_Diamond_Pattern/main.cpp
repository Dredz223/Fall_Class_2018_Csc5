/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 10, 2018, 9:03 PM
 * Purpose:  Diamond Pattern
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    
    //Input or initialize values Here
    
    //Process/Calculations Here
        
    //Output Located Here
    cout<<"     *"<<endl;
    cout<<"    ***"<<endl;
    cout<<"   *****"<<endl;
    cout<<"  *******"<<endl;
    cout<<"   *****"<<endl;
    cout<<"    ***"<<endl;
    cout<<"     *"<<endl;
    //Exit
    return 0;
}

