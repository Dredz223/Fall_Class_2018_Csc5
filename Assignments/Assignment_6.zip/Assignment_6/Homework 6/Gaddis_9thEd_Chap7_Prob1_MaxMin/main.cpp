/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on Nov 24th, 2018, 1:57 PM
 * Purpose:  Largest & Smallest
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions
//Function Prototypes Here
//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int array[10];
    int max,min;
    
    //Initialize first value
    cout<<"Please enter the first value for the array."<<endl;
    cin>>array[0];
    min=max=array[0];
    
    //Input or initialize values Here
    for(int j=1;j<10;j++){
        cout<<"Enter the rest of the values for the array. "<<endl;
        cin>>array[j];
    }
    
    //Min & max check
    for(int i=0;i<10;i++){
        if(min>array[i])min=array[i];
        if(max<array[i])max=array[i];
    }
    
    //Display the array
    cout<<"The max value is "<<max<<endl;
    cout<<"The min value is "<<min<<endl;
    //Exit
    return 0;
}