/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 20, 2018, 11:26 AM
 * Purpose:  Charge account Validation
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    const int NUMACCS=18;
    unsigned int acCTs[] = {5658845, 4520125, 7895122,
                            8777541, 8451277, 1302850,
                            8080152, 4562555, 5552012,
                            5050552, 7825877, 1250255,
                            1005231, 6545231, 3852085,
                            7576651, 7881200, 4581002 };
    
    //Ask user what number to look up
    int acct;
    do {
        cout<<"Enter the account number: ";
        cin>> acct;
        if(acct<0){
            cout<<"Invalid account number. "
                <<"Please enter a number greater than 0."<<endl;
        }
    }while(acct<0);
    
    //Search for the number in the list of valid account numbers.
    bool found = false;
    for(int i=0; i<NUMACCS;i++){
        if(acct == acCTs[i])
            found = true;
    }
   
    //Output Located Here
    if(found)
        cout << "The account number is VALID."<<endl;
    else    
    cout << "The account number is INVALID."<<endl;
    

    //Exit
    return 0;
}

