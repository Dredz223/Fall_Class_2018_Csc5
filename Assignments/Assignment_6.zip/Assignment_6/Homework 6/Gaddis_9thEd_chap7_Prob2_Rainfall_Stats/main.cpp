/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 24, 2018 5:57PM
 * Purpose:  Rainfall Stats
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl

using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    const int MONTHS=12;
    int rain[MONTHS];
    int avg;
    int yrtot;
    int min,max;
    bool valid=false;
    
    //Initial Variables
    do{
        cout<<"January's monthly rainfall."<<endl;
        cin>>rain[0];
        if(rain[0]>=0) valid=true;
        else{
            cout<<"Invalid input try again"<<endl;
        }
    }while(!valid);
    valid=false;
    max=min=rain[0];
    do{
        cout<<"February's monthly rainfall."<<endl;
        cin>>rain[1];
        if(rain[1]>=0) valid=true;
        else{
            cout<<"Invalid input try again"<<endl;
        }
    }while(!valid);
    valid=false;
    do{
        cout<<"March's monthly rainfall."<<endl;
        cin>>rain[2];
        if(rain[2]>=0) valid=true;
        else{
            cout<<"Invalid input try again"<<endl;
        }
    }while(!valid);
    valid=false;
    do{
        cout<<"April's monthly rainfall."<<endl;
        cin>>rain[3];
        if(rain[3]>=0) valid=true;
        else{
            cout<<"Invalid input try again"<<endl;
        }
    }while(!valid);
    valid=false;
    do{
        cout<<"May's monthly rainfall."<<endl;
        cin>>rain[4];
        if(rain[4]>=0) valid=true;
        else{
            cout<<"Invalid input try again"<<endl;
        }
    }while(!valid);
    valid=false;
    do{
        cout<<"June's monthly rainfall."<<endl;
        cin>>rain[5];
        if(rain[5]>=0) valid=true;
        else{
            cout<<"Invalid input try again"<<endl;
        }
    }while(!valid);
    valid=false;
    do{
        cout<<"July's monthly rainfall."<<endl;
        cin>>rain[6];
        if(rain[6]>=0) valid=true;
        else{
            cout<<"Invalid input try again"<<endl;
        }
    }while(!valid);
    valid=false;
    do{
        cout<<"August's monthly rainfall."<<endl;
        cin>>rain[7];
        if(rain[7]>=0) valid=true;
        else{
            cout<<"Invalid input try again"<<endl;
        }
    }while(!valid);
    valid=false;
    do{
        cout<<"September's monthly rainfall."<<endl;
        cin>>rain[8];
        if(rain[8]>=0) valid=true;
        else{
            cout<<"Invalid input try again"<<endl;
        }
    }while(!valid);
    valid=false;
    do{
        cout<<"October's monthly rainfall."<<endl;
        cin>>rain[9];
        if(rain[9]>=0) valid=true;
        else{
            cout<<"Invalid input try again"<<endl;
        }
    }while(!valid);
    valid=false;
    do{
        cout<<"November's monthly rainfall."<<endl;
        cin>>rain[10];
        if(rain[10]>=0) valid=true;
        else{
            cout<<"Invalid input try again"<<endl;
        }
    }while(!valid);
    valid=false;
    do{
        cout<<"December's monthly rainfall."<<endl;
        cin>>rain[11];
        if(rain[11]>=0) valid=true;
        else{
            cout<<"Invalid input try again"<<endl;
        }
    }while(!valid);
    valid=false;
    
    //Calculations
    yrtot = rain[0] + rain[1] + rain[2] + rain[3] + rain[4] +  
            rain[5] + rain[6] + rain[7] + rain[8] + rain[9] + 
            rain[10] + rain[11];
    avg = yrtot/(12);
    
    //max & min
    for(int i=0;i<10;i++){
        if(min>rain[i])min=rain[i];
        if(max<rain[i])max=rain[i];
    }
    
    //Display rainfall stats
    cout<<"The total rainfall for the year is: "<<yrtot<<endl;
    cout<<"The average rainfall for the month is: "<<avg<<endl;
    cout<<"The max rainfall is "<<max<<endl;
    cout<<"The min rainfall is "<<min<<endl;
    //Exit program!
    return 0;
}