/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 25, 2018 1:45PM
 * Purpose:  Chips and Salsa
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE =5;//Size of the array
    string salsa[SIZE]={"Mild","Medium","Sweet","Hot","Zesty"};
    int sold[SIZE];
    int max, min;//Max and min
    
    //Initial Variables
    cout<<"Please enter the amount of "<<salsa[0]<<" salsa sold."<<endl;
    cin>>sold[0];
    max=min=sold[0];
    
    //Enter the rest of the salsa sold
    for(int i=1;i<SIZE;i++){
        cout<<"Please enter the amount of "<<salsa[i]<<" salsa sold."<<endl;
        cin>>sold[i];
    }
    
    //Min & max check
    for(int i=0;i<SIZE;i++){
        if(min>sold[i])min=sold[i];
        if(max<sold[i])max=sold[i];
    }
    
    //Map/Process Inputs to Outputs
    cout<<salsa[0]<<" "<<salsa[1]<<" "<<salsa[2]<<" "
        <<salsa[3]<<" "<<salsa[4]<<endl;
    cout<<"======================================"<<endl;
    cout<<sold[0]<<setw(7)<<sold[1]<<setw(7)<<sold[2]<<setw(5)
        <<sold[3]<<setw(5)<<sold[4]<<endl;
    cout<<"The most salsa sold is: "<<max<<endl;
    cout<<"The least salsa sold is: "<<min<<endl;
    //Exit program!
    return 0;
}