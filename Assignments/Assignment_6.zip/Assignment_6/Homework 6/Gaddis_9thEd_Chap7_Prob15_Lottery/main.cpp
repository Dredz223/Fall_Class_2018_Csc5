/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 25, 2018 11:21PM
 * Purpose:  Lottery
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <cstdlib>  //Random
#include <ctime>    //Time Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Random seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    const int SIZE=5;
    int lottery[SIZE];
    int user[SIZE];
    bool numEqu=true;
    int count=0;
    
    //Ask user for their numbers for the lottery
    cout<<"Please enter your lottery numbers"<<endl;
    for(int j=0;j<SIZE;j++){
        cin>>user[j];
    }
    for(int j=0;j<SIZE;j++){
        cout<<"User's lottery numbers are: "<<user[j]<<endl;
    }
    
    //The Lottery Numbers
    for(int i=0;i<SIZE;i++){
        lottery[i]=rand()%10;
        cout<<"The lottery numbers are: "<<lottery[i]<<endl;
    }
    
    //Comparing Numbers
    while (numEqu && count<SIZE){
        if (lottery[count] != user[count])
            numEqu=false;
        count++;
    }
    if(numEqu)
        cout<<"CONGRADUKATIONS YOU WON THE GRAND PRIZE!!!"<<endl;
    else
        cout<<"Oh no. You lose. Try again."<<endl; 
    //Exit program!
    return 0;
}