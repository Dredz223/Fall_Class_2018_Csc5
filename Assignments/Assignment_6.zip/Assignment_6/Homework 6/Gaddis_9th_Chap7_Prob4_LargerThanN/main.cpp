/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 15, 2018, 9:07 AM
 * Purpose: Larger Than n
 */

//System Libraries Here
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions
const int SIZE = 10;

//Function Prototypes Here
void print(int Array[], int Size, int n);

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int A[SIZE];
    int n;
    
    //Input or initialize values Here
    srand(time(0));
    cout<<"Original random array: ";
    for(int i=0; i<SIZE; i++){
        A[i]=rand()%100;
        cout<<A[i]<<" ";
    }
    cout<<endl;
    
    //Process/Calculations Here
    do{
        cout<<"Enter the value of n (0-99): ";
        cin>>n;
        if(n<0 || n>99){
            cout<<"n must be a number between 0 and 99"<<endl;
        }
    }while(n<0 || n>99);
    
    //Output Located Here
    print(A, SIZE, n);

    //Exit
    return 0;
}

void print (int Array[], int Size, int n){
    for(int i=0; i<Size; i++){
        if(Array[i]>n){
            cout<<Array[i]<<" ";
        }
    }
    cout<<endl;
}