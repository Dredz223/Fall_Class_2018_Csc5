/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 25, 2018 1:45PM
 * Purpose:  Grade Book
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    bool valid=false;
    const int SCORE =4;//Number of test
    const int SIZE =5;//Size of the array
    string name[SIZE];//Name of the students
    char grade[SIZE]={'A','B','C','D','F'};//Grade array
    //Array for the student's score
    int score1[SCORE];
    int score2[SCORE];
    int score3[SCORE];
    int score4[SCORE];
    int score5[SCORE];
    //A-F used for total, average and grade
    int totA=0,avgA,grdA;
    int totB=0,avgB,grdB;
    int totC=0,avgC,grdC;
    int totD=0,avgD,grdD;
    int totF=0,avgF,grdF;
    
    //User input Variables ask for name of the first student and grades
    cout<<"Please enter the first student's name."<<endl;
    cin>>name[0];
    cout<<"Please enter "<<name[0]<<"'s test scores."<<endl;
    for(int i=0;i<SCORE;i++){
        do{
            cin>>score1[i];
            if(score1[i]>=0 && score1[i]<=100) {valid=true;}
            else {cout<<"Invalid grade try again"<<endl;}
        }while(!valid);
        valid=false;
        totA += score1[i];
        avgA = totA / SCORE;
    }
    
    //User input Variables ask for name of the Second student and grades
    cout<<"Please enter the second student's name."<<endl;
    cin>>name[1];
    cout<<"Please enter "<<name[1]<<"'s test scores."<<endl;
    for(int i=0;i<SCORE;i++){
        do{
            cin>>score2[i];
            if(score2[i]>=0 && score2[i]<=100) {valid=true;}
            else {cout<<"Invalid grade try again"<<endl;}
        }while(!valid);
        valid=false;
        totB += score2[i];
        avgB = totB / SCORE;
    }
    
    //User input Variables ask for name of the third student and grades
    cout<<"Please enter the third student's name."<<endl;
    cin>>name[2];
    cout<<"Please enter "<<name[2]<<"'s test scores."<<endl;
    for(int i=0;i<SCORE;i++){
        do{
            cin>>score3[i];
            if(score3[i]>=0 && score3[i]<=100) {valid=true;}
            else {cout<<"Invalid grade try again"<<endl;}
        }while(!valid);
        valid=false;
        totC += score3[i];
        avgC = totC / SCORE;
    }
    
    //User input Variables ask for name of the 4th student and grades
    cout<<"Please enter the fourth student's name."<<endl;
    cin>>name[3];
    cout<<"Please enter "<<name[3]<<"'s test scores."<<endl;
    for(int i=0;i<SCORE;i++){
        do{
            cin>>score4[i];
            if(score4[i]>=0 && score4[i]<=100) {valid=true;}
            else {cout<<"Invalid grade try again"<<endl;}
        }while(!valid);
        valid=false;
        totD += score4[i];
        avgD = totD / SCORE;
    }
    
    //User input Variables ask for name of the 5th student and grades
    cout<<"Please enter the fifth student's name."<<endl;
    cin>>name[4];
    cout<<"Please enter "<<name[4]<<"'s test scores."<<endl;
    for(int i=0;i<SCORE;i++){
        do{
            cin>>score5[i];
            if(score5[i]>=0 && score5[i]<=100) {valid=true;}
            else {cout<<"Invalid grade try again"<<endl;}
        }while(!valid);
        valid=false;
        totF += score5[i];
        avgF = totF / SCORE;
    }
    
    //Displays 1st Student's name and their average and grade
    if(avgA>=90 && avgA<=100){
        cout<<name[0]<<"'s average is "<<avgA<<" You received this grade: "
        <<grade[0]<<endl;
    }
    else if(avgA>=80 && avgA<=89){
        cout<<name[0]<<"'s average is "<<avgA<<" You received this grade: "
        <<grade[1]<<endl;
    }
    else if(avgA>=70 && avgA<=79){
        cout<<name[0]<<"'s average is "<<avgA<<" You received this grade: "
        <<grade[2]<<endl;
    }
    else if(avgA>=60 && avgA<=69){
        cout<<name[0]<<"'s average is "<<avgA<<" You received this grade: "
        <<grade[3]<<endl;
    }
    else{
        cout<<name[0]<<"'s average is "<<avgA<<" You received this grade: "
        <<grade[4]<<endl;
    }
    
    //Displays 2nd Student's name and their average and grade
    if(avgB>=90 && avgB<=100){
        cout<<name[1]<<"'s average is "<<avgB<<" You received this grade: "
        <<grade[0]<<endl;
    }
    else if(avgB>=80 && avgB<=89){
        cout<<name[1]<<"'s average is "<<avgB<<" You received this grade: "
        <<grade[1]<<endl;
    }
    else if(avgB>=70 && avgB<=79){
        cout<<name[1]<<"'s average is "<<avgB<<" You received this grade: "
        <<grade[2]<<endl;
    }
    else if(avgB>=60 && avgB<=69){
        cout<<name[1]<<"'s average is "<<avgB<<" You received this grade: "
        <<grade[3]<<endl;
    }
    else{
        cout<<name[1]<<"'s average is "<<avgB<<" You received this grade: "
        <<grade[4]<<endl;
    }
    
    //Displays 3rd Student's name and their average and grade
    if(avgC>=90 && avgC<=100){
        cout<<name[2]<<"'s average is "<<avgC<<" You received this grade: "
        <<grade[0]<<endl;
    }
    else if(avgC>=80 && avgC<=89){
        cout<<name[2]<<"'s average is "<<avgC<<" You received this grade: "
        <<grade[1]<<endl;
    }
    else if(avgC>=70 && avgC<=79){
        cout<<name[2]<<"'s average is "<<avgC<<" You received this grade: "
        <<grade[2]<<endl;
    }
    else if(avgC>=60 && avgC<=69){
        cout<<name[2]<<"'s average is "<<avgC<<" You received this grade: "
        <<grade[3]<<endl;
    }
    else{
        cout<<name[2]<<"'s average is "<<avgC<<" You received this grade: "
        <<grade[4]<<endl;
    }
    
    //Displays 4th Student's name and their average and grade
    if(avgD>=90 && avgD<=100){
        cout<<name[3]<<"'s average is "<<avgD<<" You received this grade: "
        <<grade[0]<<endl;
    }
    else if(avgD>=80 && avgD<=89){
        cout<<name[3]<<"'s average is "<<avgD<<" You received this grade: "
        <<grade[1]<<endl;
    }
    else if(avgD>=70 && avgD<=79){
        cout<<name[3]<<"'s average is "<<avgD<<" You received this grade: "
        <<grade[2]<<endl;
    }
    else if(avgD>=60 && avgD<=69){
        cout<<name[3]<<"'s average is "<<avgD<<" You received this grade: "
        <<grade[3]<<endl;
    }
    else{
        cout<<name[3]<<"'s average is "<<avgD<<" You received this grade: "
        <<grade[4]<<endl;
    }
    
    //Displays 5th Student's name and their average and grade
    if(avgF>=90 && avgF<=100){
        cout<<name[4]<<"'s average is "<<avgF<<" You received this grade: "
        <<grade[0]<<endl;
    }
    else if(avgF>=80 && avgF<=89){
        cout<<name[3]<<"'s average is "<<avgF<<" You received this grade: "
        <<grade[1]<<endl;
    }
    else if(avgF>=70 && avgF<=79){
        cout<<name[3]<<"'s average is "<<avgF<<" You received this grade: "
        <<grade[2]<<endl;
    }
    else if(avgF>=60 && avgF<=69){
        cout<<name[3]<<"'s average is "<<avgF<<" You received this grade: "
        <<grade[3]<<endl;
    }
    else{
        cout<<name[3]<<"'s average is "<<avgF<<" You received this grade: "
        <<grade[4]<<endl;
    }
    
    //Exit program!
    return 0;
}