/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 25, 2018 10:16PM
 * Purpose:  Grade Book Drop Lowest
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    bool valid=false;
    const int SCORE =4;//Number of test
    const int SIZE =5;//Size of the array
    string name[SIZE];//Name of the students
    char grade[SIZE]={'A','B','C','D','F'};//Grade array
    //Array for the student's score
    int score1[SCORE];
    int score2[SCORE];
    int score3[SCORE];
    int score4[SCORE];
    int score5[SCORE];
    //A-F used for total, average and grade and lowest
    int totA=0,avgA,grdA,lowA;
    int totB=0,avgB,grdB,lowB;
    int totC=0,avgC,grdC,lowC;
    int totD=0,avgD,grdD,lowD;
    int totF=0,avgF,grdF,lowF;
    
    //User input Variables ask for name of the first student and grades
    cout<<"Please enter the first student's name."<<endl;
    cin>>name[0];
    cout<<"Please enter "<<name[0]<<"'s test scores."<<endl;
    for(int i=0;i<SCORE;i++){
        do{
            cin>>score1[i];
            if(score1[i]>=0 && score1[i]<=100) {valid=true;}
            else {cout<<"Invalid grade try again"<<endl;}
        }while(!valid);
        valid=false;
        lowA=score1[0];
        for(int i=0;i<SCORE;i++){
        if(lowA>score1[i])lowA=score1[i];
        }
    }
    //Dropping Lowest
    cout<<"The Lowest score is: "<<lowA<<endl;
        totA = score1[0] + score1[1] + score1[2] + score1[3] - lowA;
        avgA = totA / SCORE;
    
    //User input Variables ask for name of the Second student and grades
    cout<<"Please enter the second student's name."<<endl;
    cin>>name[1];
    cout<<"Please enter "<<name[1]<<"'s test scores."<<endl;
    for(int i=0;i<SCORE;i++){
        do{
            cin>>score2[i];
            if(score2[i]>=0 && score2[i]<=100) {valid=true;}
            else {cout<<"Invalid grade try again"<<endl;}
        }while(!valid);
        valid=false;
        lowB=score2[0];
        for(int i=0;i<SCORE;i++){
        if(lowB>score2[i])lowB=score2[i];
        }
    }
    //Dropping Lowest
    cout<<"The Lowest score is: "<<lowB<<endl;
        totB = score2[0] + score2[1] + score2[2] + score2[3] - lowB;
        avgB = totB / SCORE;
    
    //User input Variables ask for name of the third student and grades
    cout<<"Please enter the third student's name."<<endl;
    cin>>name[2];
    cout<<"Please enter "<<name[2]<<"'s test scores."<<endl;
    for(int i=0;i<SCORE;i++){
        do{
            cin>>score3[i];
            if(score3[i]>=0 && score3[i]<=100) {valid=true;}
            else {cout<<"Invalid grade try again"<<endl;}
        }while(!valid);
        valid=false;
        lowC=score3[0];
        for(int i=0;i<SCORE;i++){
        if(lowC>score3[i])lowC=score3[i];
        }
    }
    //Dropping Lowest
    cout<<"The Lowest score is: "<<lowC<<endl;
        totC = score3[0] + score3[1] + score3[2] + score3[3] - lowC;
        avgC = totC / SCORE;
        
    //User input Variables ask for name of the 4th student and grades
    cout<<"Please enter the fourth student's name."<<endl;
    cin>>name[3];
    cout<<"Please enter "<<name[3]<<"'s test scores."<<endl;
    for(int i=0;i<SCORE;i++){
        do{
            cin>>score4[i];
            if(score4[i]>=0 && score4[i]<=100) {valid=true;}
            else {cout<<"Invalid grade try again"<<endl;}
        }while(!valid);
        valid=false;
        lowD=score4[0];
        for(int i=0;i<SCORE;i++){
        if(lowD>score4[i])lowD=score4[i];
        }
    }
    //Dropping Lowest
    cout<<"The Lowest score is: "<<lowD<<endl;
        totD = score4[0] + score4[1] + score4[2] + score4[3] - lowD;
        avgD = totD / SCORE;
    
    //User input Variables ask for name of the 5th student and grades
    cout<<"Please enter the fifth student's name."<<endl;
    cin>>name[4];
    cout<<"Please enter "<<name[4]<<"'s test scores."<<endl;
    for(int i=0;i<SCORE;i++){
        do{
            cin>>score5[i];
            if(score5[i]>=0 && score5[i]<=100) {valid=true;}
            else {cout<<"Invalid grade try again"<<endl;}
        }while(!valid);
        valid=false;
        lowF=score5[0];
        for(int i=0;i<SCORE;i++){
        if(lowF>score5[i])lowF=score5[i];
        }
    }
    //Dropping Lowest
    cout<<"The Lowest score is: "<<lowD<<endl;
        totF = score5[0] + score5[1] + score5[2] + score5[3] - lowF;
        avgF = totF / SCORE;
    //Displays 1st Student's name and their average and grade
    if(avgA>=90 && avgA<=100){
        cout<<name[0]<<"'s average is "<<avgA<<" You received this grade: "
        <<grade[0]<<endl;
    }
    else if(avgA>=80 && avgA<=89){
        cout<<name[0]<<"'s average is "<<avgA<<" You received this grade: "
        <<grade[1]<<endl;
    }
    else if(avgA>=70 && avgA<=79){
        cout<<name[0]<<"'s average is "<<avgA<<" You received this grade: "
        <<grade[2]<<endl;
    }
    else if(avgA>=60 && avgA<=69){
        cout<<name[0]<<"'s average is "<<avgA<<" You received this grade: "
        <<grade[3]<<endl;
    }
    else{
        cout<<name[0]<<"'s average is "<<avgA<<" You received this grade: "
        <<grade[4]<<endl;
    }
    
    //Displays 2nd Student's name and their average and grade
    if(avgB>=90 && avgB<=100){
        cout<<name[1]<<"'s average is "<<avgB<<" You received this grade: "
        <<grade[0]<<endl;
    }
    else if(avgB>=80 && avgB<=89){
        cout<<name[1]<<"'s average is "<<avgB<<" You received this grade: "
        <<grade[1]<<endl;
    }
    else if(avgB>=70 && avgB<=79){
        cout<<name[1]<<"'s average is "<<avgB<<" You received this grade: "
        <<grade[2]<<endl;
    }
    else if(avgB>=60 && avgB<=69){
        cout<<name[1]<<"'s average is "<<avgB<<" You received this grade: "
        <<grade[3]<<endl;
    }
    else{
        cout<<name[1]<<"'s average is "<<avgB<<" You received this grade: "
        <<grade[4]<<endl;
    }
    
    //Displays 3rd Student's name and their average and grade
    if(avgC>=90 && avgC<=100){
        cout<<name[2]<<"'s average is "<<avgC<<" You received this grade: "
        <<grade[0]<<endl;
    }
    else if(avgC>=80 && avgC<=89){
        cout<<name[2]<<"'s average is "<<avgC<<" You received this grade: "
        <<grade[1]<<endl;
    }
    else if(avgC>=70 && avgC<=79){
        cout<<name[2]<<"'s average is "<<avgC<<" You received this grade: "
        <<grade[2]<<endl;
    }
    else if(avgC>=60 && avgC<=69){
        cout<<name[2]<<"'s average is "<<avgC<<" You received this grade: "
        <<grade[3]<<endl;
    }
    else{
        cout<<name[2]<<"'s average is "<<avgC<<" You received this grade: "
        <<grade[4]<<endl;
    }
    
    //Displays 4th Student's name and their average and grade
    if(avgD>=90 && avgD<=100){
        cout<<name[3]<<"'s average is "<<avgD<<" You received this grade: "
        <<grade[0]<<endl;
    }
    else if(avgD>=80 && avgD<=89){
        cout<<name[3]<<"'s average is "<<avgD<<" You received this grade: "
        <<grade[1]<<endl;
    }
    else if(avgD>=70 && avgD<=79){
        cout<<name[3]<<"'s average is "<<avgD<<" You received this grade: "
        <<grade[2]<<endl;
    }
    else if(avgD>=60 && avgD<=69){
        cout<<name[3]<<"'s average is "<<avgD<<" You received this grade: "
        <<grade[3]<<endl;
    }
    else{
        cout<<name[3]<<"'s average is "<<avgD<<" You received this grade: "
        <<grade[4]<<endl;
    }
    
    //Displays 5th Student's name and their average and grade
    if(avgF>=90 && avgF<=100){
        cout<<name[4]<<"'s average is "<<avgF<<" You received this grade: "
        <<grade[0]<<endl;
    }
    else if(avgF>=80 && avgF<=89){
        cout<<name[3]<<"'s average is "<<avgF<<" You received this grade: "
        <<grade[1]<<endl;
    }
    else if(avgF>=70 && avgF<=79){
        cout<<name[3]<<"'s average is "<<avgF<<" You received this grade: "
        <<grade[2]<<endl;
    }
    else if(avgF>=60 && avgF<=69){
        cout<<name[3]<<"'s average is "<<avgF<<" You received this grade: "
        <<grade[3]<<endl;
    }
    else{
        cout<<name[3]<<"'s average is "<<avgF<<" You received this grade: "
        <<grade[4]<<endl;
    }
    
    //Exit program!
    return 0;
}