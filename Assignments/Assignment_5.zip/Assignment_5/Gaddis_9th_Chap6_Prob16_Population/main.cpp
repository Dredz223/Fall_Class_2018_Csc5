/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 11, 2018 8:28PM
 * Purpose:  Population
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes
int Population(int,int,int);
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int popu,
        yrs,
        death,
        birth;
    bool valid=false;
    //Initial Variables
    do{
    cout<<"What is the current population?"<<endl;
    cin>>popu;
        if(popu >= 2)valid=true;
        else{
            cout<<"Population size cannot be less than 2! Exiting Program"<<endl;
        }
    }while(!valid);
    valid=false;
    do{
    cout<<"What is the number of years?"<<endl;
    cin>>yrs;
        if(yrs >= 1)valid=true;
        else{
            cout<<"Years cannot be less than 1! Exiting Program"<<endl;
        }
    }while(!valid);
    valid=false;
    do{
    cout<<"What is the death rate?"<<endl;
    cin>>death;
        if(death >= 0)valid=true;
        else{
            cout<<"Death rate cannot be negative! Exiting Program"<<endl;
        }
    }while(!valid);
    valid=false;
    do{
    cout<<"What is the birth rate?"<<endl;
    cin>>birth;
        if(birth >= 0)valid=true;
        else{
            cout<<"Birth rate cannot be negative! Exiting Program"<<endl;
        }
    }while(!valid);

    //Map/Process Inputs to Outputs
    cout<<"The new population is "<<Population(popu,birth,death)<<endl;
    //Exit program!
    return 0;
}
int Population (int P, int B, int D){
    return P + B - D;
}