/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 11, 2018 5:00PM
 * Purpose:  Celsius Temperature Table
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes
float celsius(float);
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float fahit;//Fahrenheit
    cout<<fixed<<setprecision(2)<<showpoint<<endl;
    //Initial Variables
    fahit = 20;
    cout<<"Fahrenheit"<<setw(14)<<"Celsius"<<endl; 
    //Map/Process Inputs to Outputs
    for(float i=0; i<=fahit;i++){
        cout<<i<<setw(19)<<celsius(i)<<endl;
    }
    //Exit program!
    return 0;
}
float celsius(float fit){
    
    float cel;
    cel = (5.00/9.00) * (fit - 32);
    return (cel);
}