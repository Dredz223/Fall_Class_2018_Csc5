/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 11, 2018 9:45PM
 * Purpose:  Winning Division
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes
float getSales(string);
void findHighest(float,float,float,float);
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    string n1="Northeast",n2="Southeast",n3="Northwest",n4="Southwest";
    
    //Map/Process Inputs to Outputs
    findHighest(getSales(n1),getSales(n2),getSales(n3),getSales(n4));
    //Exit program!
    return 0;
}
float getSales(string name){
    float sales;
    bool valid=false;
    do{
        cout<<"Input the "<<name<<" division's quarterly sales: "<<endl;
        cin>>sales;
        if(sales>=0) valid=true;
        else cout<<"Invalid input try again"<<endl;
    }while(!valid);
    return sales;
}
void findHighest(float d1, float d2, float d3, float d4){
    cout<<fixed<<setprecision(2)<<showpoint;
    if(d1>d2&&d1>d3&&d1>d4) cout<<"Northeast was the highest with sales of $"<<d1<<endl;
    else  if(d2>d1&&d2>d3&&d2>d4) cout<<"Southeast was the highest with sales of $"<<d2<<endl;
    else  if(d3>d1&&d3>d2&&d3>d4) cout<<"Northwest was the highest with sales of $"<<d3<<endl;
    else  if(d4>d1&&d4>d3&&d4>d2) cout<<"Southwest was the highest with sales of $"<<d4<<endl;
}