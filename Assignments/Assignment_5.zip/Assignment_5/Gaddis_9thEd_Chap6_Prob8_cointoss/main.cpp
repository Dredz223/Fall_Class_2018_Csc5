/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 11, 2018 7:28PM
 * Purpose:  Coin Toss
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  //Format Library
#include <cstdlib>  //Random number
#include <cstring>  //String Library
#include <ctime>    //TIME
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes
int cointoss(int);
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int nToss;  //Number of tosses
    int num = 0;    //Number for the side
    string side;//Heads or tails
    
    //Initial Variables
    cout<<"How many times do you want to toss?"<<endl;
    cin>>nToss;
    
    //Setting random seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Map/Process Inputs to Outputs
    for (int i=1;i<=nToss;i++){
        num = cointoss(i);
        if(num == 1){
            side = "Head";
        }
        if(num == 2){
            side = "Tails";
        }
        cout<<side<<endl;
    }
    
    //Exit program!
    return 0;
}
int cointoss(int num){
    num = rand()%2+1;
    return num;
}