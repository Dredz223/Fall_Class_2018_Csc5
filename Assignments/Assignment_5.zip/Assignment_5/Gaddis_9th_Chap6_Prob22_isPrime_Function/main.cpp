/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on July 19, 2016, 9:07 AM
 * Purpose:  isPrime Function
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
bool isPrime(int);

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int range=10;
    
    //Input or initialize values Here
    
    //Process/Calculations Here
    for(int num=2; num<=range; num++){
        cout<<num<<"="<<(isPrime(num)?"Prime":"Not Prime")<<endl;
    }
    
    //Output Located Here

    //Exit
    return 0;
}

bool isPrime(int n){
    //If negative, etc...
    if(n<2)return false;
    //Initialize point to stop checking
    int stopChk=sqrt(n);
    for(int chk=2; chk<=stopChk; chk++){
        if(n%chk == 0)return false;
    }
    //Must be prime
    return true;
}