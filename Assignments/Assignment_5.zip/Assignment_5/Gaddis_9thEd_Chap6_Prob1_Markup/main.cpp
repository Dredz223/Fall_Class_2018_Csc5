/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 11, 2018 12:03PM
 * Purpose:  Markup
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes
float calculateRetail(float, float, float);
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float whlcost,
          mkupper,
          retcost;
    cout<<fixed<<setprecision(2)<<showpoint;
    //Initial Variables
    cout<<"Please enter the wholesale cost."<<endl;
    cin>>whlcost;
    cout<<"Please enter the markup percentage. (In decimal form)"<<endl;
    cin>>mkupper;
    //Validation for whole cost and markup percentage
    if(whlcost < 0 ){
        cout<<"Whole cost cannot be negative!!!\n"<<
                "Please enter a positive cost!!! Exiting program!"<<endl;
        return 1;//Exiting Program
    }
    if(mkupper < 0 ){
        cout<<"The markup percentage cannot be negative!!!\n"<<
                "Please enter a positive percentage!!! Exiting program"<<endl;
        return 2;//Exiting Program
    }
    //Map/Process Inputs to Outputs
    cout<<calculateRetail(whlcost,mkupper,retcost)<<endl;
    //Exit program!
    return 0;
}
//Calculating Retail cost
float calculateRetail(float whlcost, float mkupper, float retcost){
    
    //Calculations
    retcost = whlcost + (whlcost * (mkupper/100));
    //Display retail cost
    cout<<"The retail cost is "<<retcost<<endl;
    return (retcost);
}