/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 11, 2018 10:07PM
 * Purpose:  Safest Driving Area
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes
int getNumAcc(string);
void findLowest(int,int,int,int,int);
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    string n1="North",n2="East",n3="South",n4="West", n5="Central";
    
    //Map/Process Inputs to Outputs
    findLowest(getNumAcc(n1),getNumAcc(n2),getNumAcc(n3),getNumAcc(n4),getNumAcc(n5));
    //Exit program!
    return 0;
}
int getNumAcc(string name ){
    int total;
    bool valid=false;
    do{
        cout<<"Input the "<<name<<" region's total accidents "<<endl;
        cin>>total;
        if(total>=0) valid=true;
        else cout<<"Invalid input try again"<<endl;
    }while(!valid);
    return total;
}
void findLowest(int d1,int d2,int d3,int d4,int d5){
    cout<<fixed<<setprecision(2)<<showpoint;
    if(d1<d2&&d1<d3&&d1<d4&&d1<d5) cout<<"North was the lowest with accidents of "<<d1<<endl;
    else  if(d2<d1&&d2<d3&&d2<d4&&d2<d5) cout<<"East was the lowest with accidents of "<<d2<<endl;
    else  if(d3<d1&&d3<d2&&d3<d4&&d3<d5) cout<<"South was the lowest with accidents of "<<d3<<endl;
    else  if(d4<d1&&d4<d3&&d4<d2&&d4<d5) cout<<"West was the lowest with accidents of "<<d4<<endl;
    else  if(d5<d1&&d5<d2&&d5<d3&&d5<d4) cout<<"Central was the lowest with accidents of "<<d5<<endl;
}