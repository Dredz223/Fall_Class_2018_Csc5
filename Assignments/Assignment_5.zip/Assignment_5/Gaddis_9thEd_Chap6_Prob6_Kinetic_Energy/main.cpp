/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 11, 2018 4:21PM
 * Purpose:  Kinetic Energy
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes
float kineticEnergy(float, float);
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float mass,//Mass of the object
          vel; //Velocity of the object
    //Initial Variables
    cout<<"What is the mass of the object? "<<endl;
    cin>>mass;
    cout<<"what is the velocity of the object? "<<endl;
    cin>>vel;
    
    //Map/Process Inputs to Outputs
    cout<<"The KE = "<<kineticEnergy(mass,vel)<<endl;
    //Exit program!
    return 0;
}
float kineticEnergy(float m, float v){
    float kE;//Kinetic Energy
    kE = (0.5) * (m) * (v * v);
    return (kE);
}