/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 11, 2018 3:17PM
 * Purpose:  Falling Distance
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes
float fallingDistance(float);
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float time;//Time in seconds
    cout<<fixed<<setprecision(2)<<showpoint<<endl;
    //Initial Variables
    cout<<"Enter the time the object is falling "<<endl;
    cin>>time;
    
    cout<<"Time(s)"<<setw(14)<<"Distance"<<endl;
    //Map/Process Inputs to Outputs
    for(int i=0; i <= time; i++){
        cout<<i<<setw(14)<<fallingDistance(i)<<endl;
    }
    //Exit program!
    return 0;
}
float fallingDistance(float t){
    float dist;
    dist = (0.5) * (9.8) *(t * t);
    return (dist);
}