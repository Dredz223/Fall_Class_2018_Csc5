/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 18, 2018, 12:11 AM
 * Purpose:  Box Office
 */

//System Libraries Here
#include <iostream>//I/O stream Libriary
#include <iomanip>//
#include <cstring>//
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    string sMadLib;
    string in1,in2,in3,in4;
    
    
    //Input or initialize values Here                 
    cout<<"This Program acts like a MadLib"<<endl;
    cout<<"What is your name?"<<endl;
    getline(cin,in1);
    cout<<"What is your favorite color?"<<endl;
    getline(cin,in2);
    cout<<"What is your favorite food?"<<endl;
    getline(cin,in3);
    cout<<"What is your favorite animal?"<<endl;
    getline(cin,in4);
    
    //Process/Calculations Here
    sMadLib=in1 + " ate the "+in2+ " "+in4;
    sMadLib+=" after the "+in4;
    sMadLib+=" ate his "+in3+ ".";
            
    //Output Located Here
    cout<<sMadLib<<endl;
    
    //Exit
    return 0;
}

