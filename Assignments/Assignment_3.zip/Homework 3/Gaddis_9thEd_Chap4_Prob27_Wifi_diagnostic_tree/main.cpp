/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on October 2, 2018, 11:20 AM
 * Purpose:  Wifi Diagnositc Tree
 */

//System Libraries Here
#include <iostream>
#include <string>
using namespace std;

//User Libraries Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    cout << "Wi-Fi Troubleshooting Program\n"
         << "=============================" << endl;
    
    cout << "Reboot the computer and try to connect."
         << endl;
    
    string YesNo;
    
    cout << "Did that fix the problem? ";
        cin >> YesNo;
    
    
    //Note: Should we be concerned about UPPERCASE vs lowercase?
    if( YesNo == "no" || YesNo == "NO" ){
        cout << "Reboot the router and try to connect."
             << endl;
        
        cout << "Did that fix the problem? ";
        cin >> YesNo;
        
    if( YesNo == "no" || YesNo == "NO") {
            cout << "Make sure the cables between "
                 << "the router and modem are plugged "
                 << "in firmly."
                 << endl;
            
        cout << "Did that fix the problem? ";
        cin >> YesNo;
    if( YesNo == "no" || YesNo == "NO") {
            cout << "Move the router to a new "
                 << "location and try to connect."
                 <<endl;
        cout << "Did that fix the problem? ";
        cin >> YesNo;
    if( YesNo == "no" || YesNo == "NO") {
        cout << "Get a new router" << endl;
    }
        
            
        }
        }
    }
    //Exit
    return 0;
}

