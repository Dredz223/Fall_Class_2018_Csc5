/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on October 4, 2018 12:02PM
 * Purpose:  Personal Best
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    string name,//The name of the pole vaulter
            date1,//Date 1
            date2,//Date 2
            date3;//Date 3
    
    float  height1,//Height 1
           height2,//Height 2
           height3;//Height 3
    
    cout<<"What is the name the pole vaulter?"<<endl;
    cin>>name;
    cout<<"What are the best 3 heights the vaulter made? (in meters)"<<endl;
    cin>>height1>>height2>>height3;
    
    //Validation 
    if (height1<2 || height1>5){
        cout<<"Height must be between 2 and 5 meters!!!"<<endl;
        return(0);
    }
    if (height2<2 || height3>5){
        cout<<"Height must be between 2 and 5 meters!!!"<<endl;
        return(0);
    }
    if (height3<2 || height3>5){
        cout<<"Height must be between 2 and 5 meters!!!"<<endl;
        return(0);
    }
    
    cout<<"What are the corresponding dates for each height? (Month Date, Year)"<<endl;
    cin.ignore();
    getline(cin,date1),getline(cin,date2),getline(cin,date3);
    
    if (height1>height2 && height1>height3){
        cout<<name<<"'s best three heights and dates are "<<height1<<" meters on "<<date1<<" "<<height2<<" meters on "<<date2<<" and "<<height3<<" meters on "<<date3<<"."<<endl;
    }
    else if (height2>height1 && height2>height3){
        cout<<name<<"'s best three heights and dates are "<<height2<<" meters on "<<date2<<" "<<height1<<" meters on "<<date1<<" and "<<height3<<" meters on "<<date3<<"."<<endl;
    } 
    else if (height3>height2 && height3>height1){
        cout<<name<<"'s best three heights and dates are "<<height3<<" meters on "<<date3<<" "<<height2<<" meters on "<<date2<<" and "<<height3<<" meters on "<<date3<<"."<<endl;
    }
    
    
    return 0;
}