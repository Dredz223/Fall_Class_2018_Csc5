/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 25, 2018, 11:27 AM
 * Purpose:  Running the Race
 */

//System Libraries Here
#include <iostream>
#include <string>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    string name1,name2, name3;
    float time1, time2, time3;
    
    cout<< "Enter the name of Runner #1: ";
    cin>> name1;
    cout<< "Enter the time of Runner #1: ";
    cin>> time1;
    if( time1 <0 )
        cout<<" Error! Time must be positive"<<endl;
    
    cout<< "Enter the name of Runner #2: ";
    cin>> name2;
    cout<< "Enter the time of Runner #2: ";
    cin>> time2;
    if( time2 <0 )
        cout<<" Error! Time must be positive"<<endl;
    
    cout<< "Enter the name of Runner #3: ";
    cin>> name3;
    cout<< "Enter the time of Runner #3: ";
    cin>> time3;
    if( time3 <0 )
        cout<<" Error! Time must be positive"<<endl;
    
    //Determine which place each runner took
    string place1, place2, place3;
    if( time1 <time2 && time1 < time3)
        place1 = "first";
    else if( (time1 < time2 && time1 > time3) ||
             (time1 > time2 && time1 < time3) )
        place1 = "second";
    else place1 = "third";
    if( time2 < time1 && time2 < time3)
        place2 = "first";
    else if( (time2 < time1 && time2 > time3) ||
             (time2 > time1 && time2 < time3) )
        place2 = "second";
    else place2 = "third";
    if( time3 < time2 && time3 < time1)
        place3 = "first";
    else if( (time3 < time2 && time3 > time1) ||
             (time3 > time2 && time3 < time1) )
        place3 = "second";
    else place3 = "third";
    
    
    //Output Results
    cout<< name1 << " came in " << place1 <<"."<<endl;
    cout<< name2 << " came in " << place2 <<"."<<endl;
    cout<< name3 << " came in " << place3 <<"."<<endl;

    //Exit
    return 0;
}

