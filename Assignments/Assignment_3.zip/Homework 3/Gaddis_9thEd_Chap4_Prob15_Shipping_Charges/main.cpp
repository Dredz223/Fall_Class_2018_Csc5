/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on October 2, 2018 7:58PM
 * Purpose:  Shipping Charges 
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
//#include <string>   //String Library
//#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float wtPkge, //Weight of the Package in kilograms
          miTrv,  //Miles Traveled
          chrges; //Total charge of shipping
    cout<<" What is the weight of the package in kilograms?"<<endl;
    cin >>wtPkge;
   
    cout<<" What is the amount of miles the package traveled?"<<endl;
    cin >>miTrv;
    
    //Validate the inputs
    if(wtPkge<=0 || wtPkge>20) {
        cout<<" The weight needs to be between 1 and 20!"<<endl;
        return(0);
       }
    if(miTrv<=10 || miTrv>3000) {
        cout<<"The miles traveled needs to be between 10 and 3000!"<<endl;
        return(0); 
    }
    //Determine the weight of package
    //char wt;//char the weight
    if (wtPkge <=2) {    
        chrges= (1.10/500) * miTrv;
    } 
    else if (wtPkge >2 && wtPkge<=6) {    
        chrges= (2.20/500) * miTrv;
    }
    else if (wtPkge >6 && wtPkge<=10) {
        chrges= (3.70/500) * miTrv;
    }
    else if (wtPkge >10 && wtPkge<=20) {
        chrges= (4.80/500) * miTrv;
    }
    else{
        cout<<"NO PACKAGES OVER 20kgs!"<<endl;
    }
    //Map/Process Inputs to Outputs
    cout<<"Your total charge is $"<<chrges<<"!"<<endl;
    //Exit program!
    return 0;
}