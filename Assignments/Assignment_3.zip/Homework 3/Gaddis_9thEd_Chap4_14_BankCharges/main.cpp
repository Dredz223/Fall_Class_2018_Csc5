/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on October 4, 2018 8:31PM
 * Purpose:  Bank Charges
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
//#include <string>   //String Library
//#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float balance,//Balance of your bank
           checks,//The number of checks the user inputs
           finbal,//Final Balance after service fee  
           finbalb,//Final Balance after service fee and a deduction of $15 for falling below $400  
         servfee;//Service fee that's subtracted from the balance
    
    //Map/Process Inputs to Outputs
    cout<<"What is your bank balance?"<<endl;
    cin>>balance;
    
    cout<<"Please input the number of checks you have made."<<endl;
    cin>>checks;
    
    if (checks<20){
         servfee = 10 + (0.10*checks);
        }
    else if (checks<=20 && checks<=39){
         servfee = 10 + (0.08*checks);
        } 
    else if (checks<=40 && checks<=59){
         servfee = 10 + (0.06*checks);
        }
    else if (checks<=60){
         servfee = 10 + (0.04*checks);
        }
    
    //Initial Variables
    finbal = balance - servfee;
    cout<<"Your final balance after service fees: $"<<finbal<<endl;
   
    if(finbal<400){
        finbalb = finbal - 15;
        cout<<"Your balance after the service fee is under $400.\n"
                "You have been deducted $15. Your new final balance is\n"
                <<finbalb<<endl;
    }
    else if (finbal>=400){
        cout<<"No deduction has been applied $"<<finbal<<endl;
    }
    //Exit program!
    return 0;
}