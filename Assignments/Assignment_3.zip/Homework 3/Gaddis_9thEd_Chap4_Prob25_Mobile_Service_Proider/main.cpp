/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on October 2, 2018, 11:40 AM
 * Purpose:  Wifi Diagnositc Tree
 */

//System Libraries Here
#include <iostream>
#include <ctype.h>
#include <iomanip>
using namespace std;

//User Libraries Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Get the package and how many gigabytes were used by the user
    char Package; //Should only be 'A', 'B', or 'C'
    int giGs;//Gigabytes
    float tamtdue;//Total amount due
    Package = toupper(Package);
    
    //input
    cout << "What package do you have (A, B, or C)? ";
    cin >> Package;
    
    if( toupper(Package) != 'A' && toupper(Package) != 'B' &&
        toupper(Package) != 'C') {
        cout << "You must enter A, B, or C for the package."
             << endl;
        return 1; //wrong value for package
    }
    
    cout << "How many gigabytes did you use? ";
    cin >> giGs;
    
    
    switch(Package){
        case 'A':
            tamtdue = 39.99;
            if( giGs > 4){ 
                tamtdue += (giGs - 4) * 10;
            }
            break;
        case 'B':
            tamtdue = 59.99;
            if( giGs > 8){ 
                tamtdue += (giGs - 8) * 5;
            }
            break;    
        case 'C':
            tamtdue = 69.99;
            break;
        default:
            cout << "Package was not A, B, or C\n"
                 << " You should never get here!" << endl;
            return 2;
    }
    //Print out total amount due.
    cout << "You own $" << fixed << setprecision (2)
         << tamtdue << endl; 
    //Exit
    return 0;
}

