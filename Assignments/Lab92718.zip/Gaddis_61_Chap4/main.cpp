/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 27, 2018, 11:25 AM
 * Purpose:  Grading Problem
 */

//System Libraries Here
#include <iostream>
#include <cstdlib>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float score;
    cout << "Please enter a score: ";
    cin >> score;
    
    //Validate user input.
    
    if( score < 0 || score > 100) {
        cout << "The score needs to be between "
             << "0 and 100! (Inclusive)" << endl;
        exit(1);
    }
    
    //Determine what letter grade was earned.
    char lttrgrd;
    if( score > 90.0)
        lttrgrd = 'A';
    else if ( score >= 80.0 )
        lttrgrd = 'B';
    else if ( score >= 70.0 )
        lttrgrd = 'C';
    else if ( score >= 60.0 )
        lttrgrd = 'D';
    else lttrgrd = 'F'; 
    
    switch( lttrgrd ){
        case 'A':
            cout << "Excellent! "
                 << "You do not need to take "
                 << "the final."<<endl;
            break;
        case 'B':
            cout << "Almost!"
                 << "David you need to study harder "
                 << "in order to be the best!"<<endl;
            break;
        case 'C':
            cout << "Passing"<<endl;
            break;
        //case 'D':
        //case 'F':
            //cout << "No Bueno, Not good."
            //     << "Go study!"<<endl;
            //break;
        default:
            cout << "NOT good. Go study more!"
                 <<endl;
    }
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<"The Letter Grade is a "<<lttrgrd<<endl;

    //Exit
    return 0;
}

