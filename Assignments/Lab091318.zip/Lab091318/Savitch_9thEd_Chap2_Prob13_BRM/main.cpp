/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 13th, 2018, 12:03 PM
 * Purpose:  Justification of Candy Bar Consumption
 * 
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  //Format Library
#include <cstdlib>  //Random and set number seed
#include <ctime>    //
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    unsigned char sex,//Male ore Female M or F
                   wt,//Weight in pounds lbs
                   ht,//height in inches
                  age;//Age in years
    unsigned short bmr,//Basal Metabolic Rate
                calBar;//Calories in a Candy Bar
    float nBars;//Number of Candy Bars to consume
    
    //Initial Variables
    calBar=230;//From the book
    sex=rand()%2>0?'M':'F';//[M,F]
    wt=100+rand()%111;//[100,210] lbs
    ht=60+rand()%17;//[60,76]
    age=18+rand()%51;//[18,68]
    
    //Map/Process Inputs to Outputs
    bmr = sex=='F'?
        655 + 4.3*wt + 4.7*ht + 4.7*age:
         66 + 6.3*wt +12.9*ht + 6.8*age;
    nBars=static_cast<float>(bmr)/calBar;
    
    //Display the output
    cout<<"Stats for Candy Bars"<<endl;
    cout<<"Sex = "<<sex<<endl;
    cout<<"Weight = "<<static_cast<int>(wt)<<" lbs"<<endl;
    cout<<"Height = "<<static_cast<int>(ht)<<" ins"<<endl;
    cout<<"Age    = "<<static_cast<int>(age)<<" yrs"<<endl;
    cout<<"BMR    = "<<bmr<<" cal"<<endl;
    cout<<"# C-Bars to Consume = "<<nBars<<endl;
    
    //Exit program!
    return 0;
}