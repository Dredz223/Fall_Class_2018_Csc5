/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Movie_Data.h
 * Author: Andres Guerrero Maldonado
 *
 * Created on December 9, 2018, 11:06 PM
 */

#ifndef MOVIE_DATA_H
#define MOVIE_DATA_H
#include <iostream>
using namespace std;

#endif /* MOVIE_DATA_H */

struct MvieDta{
    string title = "Attack of the Hacker!";   //Name of the movie
    string dirtor = "Mark Lehr.";             //Name of the director
    int myear = 2019;                        //Yeah release
    int mtime = 120;                         //Length of the movie
};