/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on December 9, 2018 10:07PM
 * Purpose:  Moive Data
 *         
 */

//System Libraries
#include <iostream>     //I/O Library -> cout,endl
#include <string>       //String Library
#include <iomanip>      //Format Library
#include "Movie_Data.h" //Includes Struct code
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    MvieDta tiket; //Movie data variable
    
    //Initial Variables
    
    //Display
    cout<<"Title of the movie "<<tiket.title<<endl;
    cout<<"Director of the movie "<<tiket.dirtor<<endl;
    cout<<"Movie release date is: "<<tiket.myear<<endl;
    cout<<"The Length of the movie is: "<<tiket.mtime<<" mins."<<endl;
    
    //Exit program!
    return 0;
}