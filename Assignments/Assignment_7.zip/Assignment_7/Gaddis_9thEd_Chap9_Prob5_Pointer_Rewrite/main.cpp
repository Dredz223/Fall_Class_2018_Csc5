/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 29, 2018 12:06PM
 * Purpose:  Pointer Rewrite
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes
int doSomething(int &x, int &y); 
int doSomething2(int *x, int *y); 

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int x=2, y=3;
    
    //int z= doSomething(x,y);
    int w= doSomething2(&x,&y);
    
    //Initial Variables
    
    //Map/Process Inputs to Outputs
    cout<<"x="<<x<<" y="<<y<<" w="<<w<<endl;
    //Exit program!
    return 0;
}
int doSomething(int &x, int &y){
    int temp=x;
    x=y*10;
    y=temp*10;
    return x+y;
}
int doSomething2(int *x, int *y){
    int temp=*x;
    *x=*y*10;
    *y=temp*10;
    return *x+*y;
}