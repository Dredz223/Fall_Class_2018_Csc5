/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 29, 2018 11:24AM
 * Purpose:  Array Allocator
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns
const int SIZE=20;
//Function Prototypes
int *Allocate(int size);
void FillArray(int *array, int size);
void PrintArray(int *array, int size);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int *array;
    
    //Initial Variables
    array= Allocate(SIZE);
    FillArray(array, SIZE);
    PrintArray(array, SIZE);
    
    //Map/Process Inputs to Outputs
    
    
    //Delete array memory
    
    delete [] array;
    
    
    //Exit program!
    return 0;
}
int *Allocate(int size){
    int *p = new int[size];
    
    return p;
}
void FillArray(int *array, int size){
    for(int i=0;i<size;i++){
        array[i]=i;
    }
}
void PrintArray(int *array, int size){
    for(int i=0;i<size;i++){
        cout<<array[i]<<' ';
    }
    cout<<endl;
}