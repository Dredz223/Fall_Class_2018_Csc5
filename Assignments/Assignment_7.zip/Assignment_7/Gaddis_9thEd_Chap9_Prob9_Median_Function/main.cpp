/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on November 29, 2018 12:17PM
 * Purpose:  Median Function
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library
#include <cstdlib>
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns
const int SIZE=11;
//Function Prototypes
void FillArray(int *p, int Size);
void PrintArray(int *array, int size);
void SortArray(int *array, int size);
double FindMedian(int *p,int SIZE);
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int *array=new int [SIZE];
    //Initial Variables
    
    //Map/Process Inputs to Outputs
    FillArray(array,SIZE);
    PrintArray(array,SIZE);
    SortArray(array,SIZE);
    PrintArray(array,SIZE);
    
    
    double median= FindMedian(array,SIZE);
    cout<<"Median = "<<median<<endl;
    
    //Exit program!
    return 0;
}
void FillArray(int *p, int size){
    for(int i=0;i<size;i++){
        p[i]=rand()%100;
    }
}
void PrintArray(int *array, int Size){
    for(int i=0;i<Size;i++){
        cout<<array[i]<<' ';
    }
    cout<<endl;
}
void SortArray(int *p, int Size){
    for(int i=0;i<Size-1;i++){
        for(int j=i+1;j<Size;j++){
            if(p[i]>p[j]){//swap
                int temp =p[i];
                p[i]=p[j];
                p[j]=temp;
            }
        }
    }
}
double FindMedian(int *p,int Size){
    int index = Size/2;
    if(Size%2 == 0){//Even
        return (p[index] + p[index-1])/2.0;
    }
    else{//Odd
        return static_cast<double>(p[index]);
    }
}