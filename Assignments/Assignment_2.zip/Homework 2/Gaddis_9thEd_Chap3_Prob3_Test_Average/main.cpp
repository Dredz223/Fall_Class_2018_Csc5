/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 18, 2018, 11:11 AM
 * Purpose:  Test Average
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    short   tstAvgA,//Test Average A
            tstAvgB,//Test Average B
            tstAvgC,//Test Average C
            tstAvgD,//Test Average D
            tstAvgE,//Test Average E
            tot;//Total Average before dividing
    float    totAvg;//Total Average
    
    //Input or initialize values Here
    cout<<"Test Average A"<<endl;
    cin>>tstAvgA;
    cout<<"Test Average B"<<endl;
    cin>>tstAvgB;
    cout<<"Test Average C"<<endl;
    cin>>tstAvgC;
    cout<<"Test Average D"<<endl;
    cin>>tstAvgD;
    cout<<"Test Average E"<<endl;
    cin>>tstAvgE;
    
    //Process/Calculations Here
    totAvg= (tstAvgA + tstAvgB + tstAvgC + tstAvgD + tstAvgE)/5;         
    //Output Located Here
    cout<<"Total Average Test Scores "<<totAvg<<endl;
    
    //Exit
    return 0;
}

