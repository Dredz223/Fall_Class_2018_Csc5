/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 18, 2018 7:58PM
 * Purpose:  Amount of Ingredients for cookies
 *           
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    const float sGr= 1.5,//Cups of Sugar for 48 cookies
                bUtr= 1.0,//Cups of Butter for 48 cookies
                fLur= 2.75,//Cups of Flour for 48 cookies
                cKes= 48;//Amount of Cookies for 48 cookies
    
    float totsGr,//Total used Sugar
          totbUtr,//Total used  Butter
          totfLur,//Total used Flour
          numcKes;//Number of Cookies
    
    //Initial Variables
    cout<<"How many cookies do you want to make? "<<endl;
    cin>>numcKes;
    
    //Calculations
    totsGr  = ( sGr * numcKes) / cKes;
    totbUtr = (bUtr * numcKes) / cKes;
    totfLur = (fLur * numcKes) / cKes;
    
    //Map/Process Inputs to Outputs
    cout<<"To make "<<numcKes<<" cookies";
    cout<<" you will need the following ingredients: \n";
    cout<<" - "<< totsGr<<"  cups of Sugar\n";
    cout<<" - "<< totbUtr<<"    cups of Butter\n";
    cout<<" - "<< totfLur<<" cups of Flour\n";
    cout<<endl;

    //Exit program!
    return 0;
}