/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 18, 2018 10:47 PM
 * Purpose:  Average rainfall for 3 months
 *           
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  //Format Library
#include <cstring>
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    const int numMon=3;//Number of months
    
    string  monA,
            monB,
            monC;
    
    float   monArnf,//Month A Rainfall
            monBrnf,//Month B Rainfall
            monCrnf,//Month C Rainfall
            totrnf,//Total Rainfall
            avgrnf;//Average Rainfall
   
    //Initial Variables
    cout<<"Please enter the name of month "<<endl; 
    cin>>monA;
    cout<<"How many inches of rain fell for "<<monA;
    cin>>monArnf;
    cout<<"Please enter the name of month "<<endl; 
    cin>>monB;
    cout<<"How many inches of rain fell for "<<monB;
    cin>>monBrnf;
    cout<<"Please enter the name of month "<<endl; 
    cin>>monC;
    cout<<"How many inches of rain fell for "<<monC;
    cin>>monCrnf;
    
    //Calculations
    totrnf = monArnf + monBrnf + monCrnf;
    avgrnf = totrnf / numMon;
    
    //Map/Process Inputs to Outputs
    cout<<"The average rainfall for ";
    cout<< monA<<", "<<monB<<", "<<"and ";
    cout<< monC<<" is ";
    cout<< avgrnf<< " inches."<<endl;
    //Exit program!
    return 0;
}