/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 18, 2018, 12:40 AM
 * Purpose:  Consumer Loan
 */

//System Libraries Here
#include <iostream>//I/O stream Libriary
#include <iomanip>//
#include <cstring>//
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float loanFV;//Loan Face Value $'s
    float loanAmt;//Loan Received in hand $'s
    float intRate;//Interest Rate/yr
    float mnPymt;//Monthly Payment in $'s
    unsigned short nMonths;//Number of Months
    
    //Input or initialize values Here
    intRate=0.15f;//15 percent
    nMonths=18;//18 months
    cout<<"consumer Loan"<<endl;
    cout<<"Input amount received in load $'s"<<endl;
    cin>>loanAmt;

    //Process/Calculations Here
    loanFV=loanAmt/(1-intRate*nMonths/12);
    mnPymt=loanFV/nMonths;
    //Output Located Here
    cout<<"$"<<loanAmt<<" @"<<intRate*100<<" % \n";
    cout<<"for "<<nMonths<<" months = Face Value of "<<endl;
    cout<<loanFV;
    cout<<fixed<<setprecision(2)<<showpoint<<endl;
    cout<<"Monthly Payment = $"<<mnPymt<<endl;
    //Exit
    return 0;
}

