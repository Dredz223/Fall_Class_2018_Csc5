/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 18, 2018, 11:28 PM
 * Purpose:  Word Game
 */

//System Libraries Here
#include <iostream>//I/O stream Libriary
#include <iomanip>//
#include <cstring>//
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    string sWordGame;
    string in1,in2,in3,in4,in5,in6,in7;
    
    
    //Input or initialize values Here                 
    cout<<"This Program will ask you questions"<<endl;
    cout<<"What is your name?"<<endl;
    getline(cin,in1);
    cout<<"What is your age?"<<endl;
    getline(cin,in2);
    cout<<"What is the name of your city?"<<endl;
    getline(cin,in3);
    cout<<"What is the name of your college?"<<endl;
    getline(cin,in4);
    cout<<"What is your profession?"<<endl;
    getline(cin,in5);
    cout<<"What is your favorite animal?"<<endl;
    getline(cin,in6);
    cout<<"What is your animal's name?"<<endl;
    getline(cin,in7);
    
    //Process/Calculations Here
    sWordGame="There once was a person named "+in1 + " who lived in "+in3+ ". ";
    sWordGame+=" At the age of "+in2+", "+in1+" went to college at "+in4+". ";
    sWordGame+=in1+" graduated and went to work as a "+in5+ ".";
    sWordGame+=" Then "+in1+ " adopted a(n)"+in6+" named "+in7+". ";
    sWordGame+="They both lived happily ever after!";
            
    //Output Located Here
    cout<<sWordGame<<endl;
    
    //Exit
    return 0;
}

